# Bilgisayarsız APK Nasıl Derlenir?

Bu proje, telefonunuzdan bile (GitHub + GitHub Actions kullanarak) derlenebilir.
Aşağıdaki adımları GitHub uygulaması veya tarayıcıdan yapabilirsiniz.

## Adım 1 — GitHub hesabı açın
github.com üzerinden ücretsiz bir hesap oluşturun (yoksa).

## Adım 2 — Yeni bir repo (depo) oluşturun
1. GitHub'da "New repository" (Yeni depo) butonuna basın.
2. Adını örneğin `icloud-webview-app` koyun, "Public" veya "Private" seçin, oluşturun.

## Adım 3 — Bu proje dosyalarını repoya yükleyin
1. Oluşturduğunuz reponun sayfasında "Add file" > "Upload files" seçeneğine tıklayın.
2. Bu projedeki TÜM klasör ve dosyaları (build.gradle, settings.gradle,
   app/ klasörü, .github/ klasörü vb.) sürükleyip bırakın veya seçip yükleyin.
   (Tarayıcıdan klasör yapısını korumak için dosyaları teker teker değil,
   ZIP'i bilgisayarda değil telefonda bir dosya yöneticisiyle klasör klasör
   sürüklemeniz gerekebilir — GitHub mobil tarayıcısı klasör yüklemeyi
   destekliyor.)
3. "Commit changes" ile onaylayın.

## Adım 4 — Otomatik derlemenin çalışmasını bekleyin
1. Reponun üstündeki "Actions" sekmesine girin.
2. "Build APK" adlı workflow'un otomatik başladığını göreceksiniz
   (dosyaları yükleyince otomatik tetiklenir).
3. Birkaç dakika sürer. Yeşil tik ✅ görünce tamamlanmış demektir.

## Adım 5 — APK dosyasını indirin
1. Tamamlanan workflow'a tıklayın.
2. En altta "Artifacts" (Yapı Çıktıları) bölümünde
   `icloud-webview-apk` dosyasını göreceksiniz, telefonunuza indirin.
3. İndirilen .zip dosyasının içinden `app-debug.apk` dosyasını çıkarın.
4. Telefonunuzda "Bilinmeyen kaynaklardan yükleme" iznini açıp
   APK'ya dokunarak kurun.

## Notlar
- Bu APK "debug" sürümdür — kendi cihazınızda kurup kullanmak için
  yeterlidir, Play Store'a yüklemek için "release" imzalı bir sürüm
  gerekir (isterseniz onu da anlatabilirim).
- Uygulama sadece https://www.icloud.com adresini açar.
  Farklı bir site açmasını isterseniz `MainActivity.java`
  içindeki `TARGET_URL` satırını değiştirip tekrar yüklemeniz yeterli.
- Alternatif olarak Termux + Android SDK kurup telefonun kendisinde
  derlemek de mümkün ama bu yöntem çok daha karmaşık ve yavaştır;
  GitHub Actions yöntemi önerilir.
